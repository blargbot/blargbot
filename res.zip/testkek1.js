/*
 * The premise of a message-awaiter is simple. You need the following:
 * 1. An object to store messages
 * 2. A function to populate the object
 * 3. A hook to check this object
 *
 * DISCLAIMER: This gist is untested and should only be looked at for learning purposes.
 * Please do not directly copy/paste it into your production environment.
 */

/**
 * A container to put await information into. Will have the folloing data structure:
 * {
 *   channelId: {
 *     userId: {
 *       resolve: Function(),
 *       callback: Function()
 *     }
 *   }
 * }
 */
var awaitedMessages = {};

/**
 * @description This functions takes a message object, and a verification callback.
 * The callback is used to verify input, rather than return a result.
 * You may expand this as needed.
 * @param {Message} msg The message object
 * @param {Function} callback A verification callback, taking a new Message object and returning a boolean
 * @returns {Promise}
 */
function awaitMessage(msg, callback) {
    return new Promise((resolve, reject) => {
        /* Verify the contents of the object */
        if (!awaitedMessages[msg.channel.id])
            awaitedMessages[msg.channel.id] = {};

        /* Create an empty entry for the user, overwriting any old one */
        awaitedMessages[msg.channel.id][msg.author.id] = {
            resolve,
            callback
        };
    });
}

/**
 * Finally, we need to hook into the awaitedMessages object.
 */
bot.on('messageCreate', msg => {
    /* Check if the object has the right channel-author combo */
    if (awaitedMessages.hasOwnProperty(msg.channel.id)
        && awaitedMessages[msg.channel.id].hasOwnProperty(msg.author.id)) {
        /* Verify input */
        if (awaitedMessages[msg.channel.id][msg.author.id].callback(msg)) {
            /* Resolve the promise */
            awaitedMessages[msg.channel.id][msg.author.id].resolve(msg);
        }
    }
});

/**
 * Examples
 */

/* eslint-disable no-undef */

// Return a message containing the word "meow", case insensitive
awaitMessage(msg, msg2 => msg2.content.toLowerCase().includes('meow'))
    .then(msg2 => {
        // Do what you want with msg2
    });

// Return a message containing a number
awaitMessage(msg, msg2 => !isNaN(parseInt(msg2.content)))
    .then(msg2 => {
        // Do what you want with msg2
    });

/* eslint-enable no-undef */